﻿namespace GetResultFormulas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.cmbFluid = new System.Windows.Forms.ComboBox();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFRSO = new System.Windows.Forms.TextBox();
            this.txtIPMaxF = new System.Windows.Forms.TextBox();
            this.txtIPNF = new System.Windows.Forms.TextBox();
            this.cmbUnit = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtIPMinF = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbIPUnit2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbIPUnit1 = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtOPMaxF = new System.Windows.Forms.TextBox();
            this.txtOPMinF = new System.Windows.Forms.TextBox();
            this.txtOPNF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtITMaxF = new System.Windows.Forms.TextBox();
            this.txtITMinF = new System.Windows.Forms.TextBox();
            this.txtITNF = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbITUnit = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtFRMaxF = new System.Windows.Forms.TextBox();
            this.txtFRMinF = new System.Windows.Forms.TextBox();
            this.txtFRNF = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMAS = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbOut2 = new System.Windows.Forms.ComboBox();
            this.cmbOut1 = new System.Windows.Forms.ComboBox();
            this.cmbIn2 = new System.Windows.Forms.ComboBox();
            this.cmbIn1 = new System.Windows.Forms.ComboBox();
            this.cmbVBSize = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbVBSTD = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cmbVBPT = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbVBPM = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbVBFD = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbVBRP = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtTrimXT = new System.Windows.Forms.TextBox();
            this.txtTrimFL = new System.Windows.Forms.TextBox();
            this.cmbTType = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbTBU = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.cmbTC = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.cmbTSize = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cmbAAFV = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.cmbABR2 = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cmbABR1 = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.cmbASize = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtITSNF = new System.Windows.Forms.TextBox();
            this.txtITSMaxF = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtITSMinF = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbITSUnit = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.txtAMM = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtAEA = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txtSWMWNF = new System.Windows.Forms.TextBox();
            this.txtVSHRNF = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.txtAPSNF = new System.Windows.Forms.TextBox();
            this.txtAPSMaxF = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txtAPSMinF = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txtVVNF = new System.Windows.Forms.TextBox();
            this.txtVVMaxF = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtVVMinF = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.txtRFCNF = new System.Windows.Forms.TextBox();
            this.txtRFCMaxF = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtRFCMinF = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.txtTravelNF = new System.Windows.Forms.TextBox();
            this.txtTravelMaxF = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtTravelMinF = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.cmbTravelUnit = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtCPress = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtLPD = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(967, 373);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Excute";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // cmbFluid
            // 
            this.cmbFluid.FormattingEnabled = true;
            this.cmbFluid.Items.AddRange(new object[] {
            "Acetylene",
            "AIR",
            "AMMONIA",
            "ARGON",
            "BENZENE",
            "BUTANE",
            "CARBON DIOXIDE",
            "CARBON MONOXIDE",
            "CHLORINE",
            "DOWTHERM-A",
            "ETHANE",
            "ETHYLENE",
            "FLUORINE",
            "GLYCOL",
            "HELIUM",
            "HYDROGEN",
            "HYDROGEN CHLORIDE",
            "Hydrogen Sulphide",
            "ISOBUTANE",
            "ISOBUTYLENE",
            "METHANE",
            "METHANOL",
            "NATURAL GAS",
            "Neon, Krypton",
            "NITROGEN",
            "Nitrogen (Nitric) Oxide",
            "NITROUS OXIDE",
            "OXYGEN",
            "PHOSGENE",
            "PROPANE",
            "PROPYLENE",
            "STEAM Saturated",
            "STEAM Superheated",
            "Sulphur Dioxide",
            "WATER",
            "Other :",
            "2-Phased Flow :"});
            this.cmbFluid.Location = new System.Drawing.Point(503, 160);
            this.cmbFluid.Name = "cmbFluid";
            this.cmbFluid.Size = new System.Drawing.Size(100, 21);
            this.cmbFluid.TabIndex = 3;
            this.cmbFluid.Text = " ";
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(719, 160);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(100, 21);
            this.cmbState.TabIndex = 3;
            this.cmbState.Text = " ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(441, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Fluid";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(656, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "State";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Shut-Off";
            // 
            // txtFRSO
            // 
            this.txtFRSO.Location = new System.Drawing.Point(76, 126);
            this.txtFRSO.Name = "txtFRSO";
            this.txtFRSO.Size = new System.Drawing.Size(100, 20);
            this.txtFRSO.TabIndex = 6;
            this.txtFRSO.Text = "10";
            // 
            // txtIPMaxF
            // 
            this.txtIPMaxF.Location = new System.Drawing.Point(70, 48);
            this.txtIPMaxF.Name = "txtIPMaxF";
            this.txtIPMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtIPMaxF.TabIndex = 6;
            this.txtIPMaxF.Text = "20";
            // 
            // txtIPNF
            // 
            this.txtIPNF.Location = new System.Drawing.Point(70, 74);
            this.txtIPNF.Name = "txtIPNF";
            this.txtIPNF.Size = new System.Drawing.Size(100, 20);
            this.txtIPNF.TabIndex = 6;
            this.txtIPNF.Text = "15";
            // 
            // cmbUnit
            // 
            this.cmbUnit.FormattingEnabled = true;
            this.cmbUnit.Location = new System.Drawing.Point(76, 21);
            this.cmbUnit.Name = "cmbUnit";
            this.cmbUnit.Size = new System.Drawing.Size(100, 21);
            this.cmbUnit.TabIndex = 3;
            this.cmbUnit.Text = " ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Unit";
            // 
            // txtIPMinF
            // 
            this.txtIPMinF.Location = new System.Drawing.Point(70, 100);
            this.txtIPMinF.Name = "txtIPMinF";
            this.txtIPMinF.Size = new System.Drawing.Size(100, 20);
            this.txtIPMinF.TabIndex = 6;
            this.txtIPMinF.Text = "20";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbIPUnit2);
            this.groupBox1.Controls.Add(this.txtIPMaxF);
            this.groupBox1.Controls.Add(this.txtIPMinF);
            this.groupBox1.Controls.Add(this.txtIPNF);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbIPUnit1);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Location = new System.Drawing.Point(221, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(229, 135);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inlet Pressure";
            // 
            // cmbIPUnit2
            // 
            this.cmbIPUnit2.FormattingEnabled = true;
            this.cmbIPUnit2.Location = new System.Drawing.Point(172, 18);
            this.cmbIPUnit2.Name = "cmbIPUnit2";
            this.cmbIPUnit2.Size = new System.Drawing.Size(51, 21);
            this.cmbIPUnit2.TabIndex = 7;
            this.cmbIPUnit2.Text = " ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Min Flow";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Norm Flow";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Max Flow";
            // 
            // cmbIPUnit1
            // 
            this.cmbIPUnit1.FormattingEnabled = true;
            this.cmbIPUnit1.Location = new System.Drawing.Point(70, 18);
            this.cmbIPUnit1.Name = "cmbIPUnit1";
            this.cmbIPUnit1.Size = new System.Drawing.Size(100, 21);
            this.cmbIPUnit1.TabIndex = 3;
            this.cmbIPUnit1.Text = " ";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(11, 22);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(26, 13);
            this.label51.TabIndex = 4;
            this.label51.Text = "Unit";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtOPMaxF);
            this.groupBox2.Controls.Add(this.txtOPMinF);
            this.groupBox2.Controls.Add(this.txtOPNF);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(456, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 135);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Outlet Pressure";
            // 
            // txtOPMaxF
            // 
            this.txtOPMaxF.Location = new System.Drawing.Point(75, 30);
            this.txtOPMaxF.Name = "txtOPMaxF";
            this.txtOPMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtOPMaxF.TabIndex = 6;
            this.txtOPMaxF.Text = "12";
            // 
            // txtOPMinF
            // 
            this.txtOPMinF.Location = new System.Drawing.Point(75, 82);
            this.txtOPMinF.Name = "txtOPMinF";
            this.txtOPMinF.Size = new System.Drawing.Size(100, 20);
            this.txtOPMinF.TabIndex = 6;
            this.txtOPMinF.Text = "12";
            // 
            // txtOPNF
            // 
            this.txtOPNF.Location = new System.Drawing.Point(75, 56);
            this.txtOPNF.Name = "txtOPNF";
            this.txtOPNF.Size = new System.Drawing.Size(100, 20);
            this.txtOPNF.TabIndex = 6;
            this.txtOPNF.Text = "12";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Min Flow";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Norm Flow";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Max Flow";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtITMaxF);
            this.groupBox3.Controls.Add(this.txtITMinF);
            this.groupBox3.Controls.Add(this.txtITNF);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.cmbITUnit);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Location = new System.Drawing.Point(659, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(181, 135);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Inlet Temperature";
            // 
            // txtITMaxF
            // 
            this.txtITMaxF.Location = new System.Drawing.Point(65, 52);
            this.txtITMaxF.Name = "txtITMaxF";
            this.txtITMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtITMaxF.TabIndex = 6;
            this.txtITMaxF.Text = "20";
            // 
            // txtITMinF
            // 
            this.txtITMinF.Location = new System.Drawing.Point(65, 104);
            this.txtITMinF.Name = "txtITMinF";
            this.txtITMinF.Size = new System.Drawing.Size(100, 20);
            this.txtITMinF.TabIndex = 6;
            this.txtITMinF.Text = "35";
            // 
            // txtITNF
            // 
            this.txtITNF.Location = new System.Drawing.Point(65, 78);
            this.txtITNF.Name = "txtITNF";
            this.txtITNF.Size = new System.Drawing.Size(100, 20);
            this.txtITNF.TabIndex = 6;
            this.txtITNF.Text = "35";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 107);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Min Flow";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Norm Flow";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(2, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Max Flow";
            // 
            // cmbITUnit
            // 
            this.cmbITUnit.FormattingEnabled = true;
            this.cmbITUnit.Location = new System.Drawing.Point(66, 21);
            this.cmbITUnit.Name = "cmbITUnit";
            this.cmbITUnit.Size = new System.Drawing.Size(100, 21);
            this.cmbITUnit.TabIndex = 3;
            this.cmbITUnit.Text = " ";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(7, 25);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(26, 13);
            this.label52.TabIndex = 4;
            this.label52.Text = "Unit";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtFRMaxF);
            this.groupBox4.Controls.Add(this.txtFRMinF);
            this.groupBox4.Controls.Add(this.txtFRNF);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.txtFRSO);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.cmbUnit);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(11, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 161);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Flow Rate";
            // 
            // txtFRMaxF
            // 
            this.txtFRMaxF.Location = new System.Drawing.Point(76, 48);
            this.txtFRMaxF.Name = "txtFRMaxF";
            this.txtFRMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtFRMaxF.TabIndex = 6;
            this.txtFRMaxF.Text = "7000";
            // 
            // txtFRMinF
            // 
            this.txtFRMinF.Location = new System.Drawing.Point(76, 100);
            this.txtFRMinF.Name = "txtFRMinF";
            this.txtFRMinF.Size = new System.Drawing.Size(100, 20);
            this.txtFRMinF.TabIndex = 6;
            this.txtFRMinF.Text = "10";
            // 
            // txtFRNF
            // 
            this.txtFRNF.Location = new System.Drawing.Point(76, 74);
            this.txtFRNF.Name = "txtFRNF";
            this.txtFRNF.Size = new System.Drawing.Size(100, 20);
            this.txtFRNF.TabIndex = 6;
            this.txtFRNF.Text = "5000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 103);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "Min Flow";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Norm Flow";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Max Flow";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(220, 164);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Min Air Supply";
            // 
            // txtMAS
            // 
            this.txtMAS.Location = new System.Drawing.Point(300, 160);
            this.txtMAS.Name = "txtMAS";
            this.txtMAS.Size = new System.Drawing.Size(100, 20);
            this.txtMAS.TabIndex = 6;
            this.txtMAS.Text = "4.0";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.cmbOut2);
            this.groupBox5.Controls.Add(this.cmbOut1);
            this.groupBox5.Controls.Add(this.cmbIn2);
            this.groupBox5.Controls.Add(this.cmbIn1);
            this.groupBox5.Location = new System.Drawing.Point(684, 198);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(247, 90);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "LINE( Pipe Size And  Schedule )";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(36, 57);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 13);
            this.label19.TabIndex = 4;
            this.label19.Text = "Out";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(41, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(16, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "In";
            // 
            // cmbOut2
            // 
            this.cmbOut2.FormattingEnabled = true;
            this.cmbOut2.Location = new System.Drawing.Point(150, 54);
            this.cmbOut2.Name = "cmbOut2";
            this.cmbOut2.Size = new System.Drawing.Size(77, 21);
            this.cmbOut2.TabIndex = 3;
            this.cmbOut2.Text = " ";
            // 
            // cmbOut1
            // 
            this.cmbOut1.FormattingEnabled = true;
            this.cmbOut1.Location = new System.Drawing.Point(67, 54);
            this.cmbOut1.Name = "cmbOut1";
            this.cmbOut1.Size = new System.Drawing.Size(77, 21);
            this.cmbOut1.TabIndex = 3;
            this.cmbOut1.Text = " ";
            // 
            // cmbIn2
            // 
            this.cmbIn2.FormattingEnabled = true;
            this.cmbIn2.Location = new System.Drawing.Point(150, 24);
            this.cmbIn2.Name = "cmbIn2";
            this.cmbIn2.Size = new System.Drawing.Size(77, 21);
            this.cmbIn2.TabIndex = 3;
            this.cmbIn2.Text = " ";
            // 
            // cmbIn1
            // 
            this.cmbIn1.FormattingEnabled = true;
            this.cmbIn1.Location = new System.Drawing.Point(67, 24);
            this.cmbIn1.Name = "cmbIn1";
            this.cmbIn1.Size = new System.Drawing.Size(77, 21);
            this.cmbIn1.TabIndex = 3;
            this.cmbIn1.Text = " ";
            // 
            // cmbVBSize
            // 
            this.cmbVBSize.FormattingEnabled = true;
            this.cmbVBSize.Location = new System.Drawing.Point(107, 53);
            this.cmbVBSize.Name = "cmbVBSize";
            this.cmbVBSize.Size = new System.Drawing.Size(121, 21);
            this.cmbVBSize.TabIndex = 3;
            this.cmbVBSize.Text = " ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(15, 56);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(31, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Size*";
            // 
            // cmbVBSTD
            // 
            this.cmbVBSTD.FormattingEnabled = true;
            this.cmbVBSTD.Location = new System.Drawing.Point(107, 26);
            this.cmbVBSTD.Name = "cmbVBSTD";
            this.cmbVBSTD.Size = new System.Drawing.Size(121, 21);
            this.cmbVBSTD.TabIndex = 3;
            this.cmbVBSTD.Text = " ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(15, 29);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "STD";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cmbVBSTD);
            this.groupBox6.Controls.Add(this.cmbVBPT);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.cmbVBPM);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.cmbVBFD);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.cmbVBRP);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.cmbVBSize);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Location = new System.Drawing.Point(91, 199);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(247, 190);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "VALVE BODY / BONNET";
            // 
            // cmbVBPT
            // 
            this.cmbVBPT.FormattingEnabled = true;
            this.cmbVBPT.Location = new System.Drawing.Point(107, 161);
            this.cmbVBPT.Name = "cmbVBPT";
            this.cmbVBPT.Size = new System.Drawing.Size(121, 21);
            this.cmbVBPT.TabIndex = 3;
            this.cmbVBPT.Text = " ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(15, 164);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 13);
            this.label26.TabIndex = 4;
            this.label26.Text = "Packing Type*";
            // 
            // cmbVBPM
            // 
            this.cmbVBPM.FormattingEnabled = true;
            this.cmbVBPM.Location = new System.Drawing.Point(107, 134);
            this.cmbVBPM.Name = "cmbVBPM";
            this.cmbVBPM.Size = new System.Drawing.Size(121, 21);
            this.cmbVBPM.TabIndex = 3;
            this.cmbVBPM.Text = " ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 137);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "Packing Material*";
            // 
            // cmbVBFD
            // 
            this.cmbVBFD.FormattingEnabled = true;
            this.cmbVBFD.Location = new System.Drawing.Point(107, 107);
            this.cmbVBFD.Name = "cmbVBFD";
            this.cmbVBFD.Size = new System.Drawing.Size(121, 21);
            this.cmbVBFD.TabIndex = 3;
            this.cmbVBFD.Text = " ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(15, 110);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(78, 13);
            this.label24.TabIndex = 4;
            this.label24.Text = "Flow Direction*";
            // 
            // cmbVBRP
            // 
            this.cmbVBRP.FormattingEnabled = true;
            this.cmbVBRP.Location = new System.Drawing.Point(107, 80);
            this.cmbVBRP.Name = "cmbVBRP";
            this.cmbVBRP.Size = new System.Drawing.Size(121, 21);
            this.cmbVBRP.TabIndex = 3;
            this.cmbVBRP.Text = " ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 83);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Rating PN";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtTrimXT);
            this.groupBox7.Controls.Add(this.txtTrimFL);
            this.groupBox7.Controls.Add(this.cmbTType);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.cmbTBU);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.cmbTC);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.cmbTSize);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Location = new System.Drawing.Point(355, 199);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(305, 190);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "TRIM";
            // 
            // txtTrimXT
            // 
            this.txtTrimXT.Location = new System.Drawing.Point(148, 162);
            this.txtTrimXT.Name = "txtTrimXT";
            this.txtTrimXT.Size = new System.Drawing.Size(121, 20);
            this.txtTrimXT.TabIndex = 6;
            this.txtTrimXT.Text = "0.72";
            // 
            // txtTrimFL
            // 
            this.txtTrimFL.Location = new System.Drawing.Point(148, 137);
            this.txtTrimFL.Name = "txtTrimFL";
            this.txtTrimFL.Size = new System.Drawing.Size(121, 20);
            this.txtTrimFL.TabIndex = 6;
            this.txtTrimFL.Text = "0.9";
            // 
            // cmbTType
            // 
            this.cmbTType.FormattingEnabled = true;
            this.cmbTType.Location = new System.Drawing.Point(148, 26);
            this.cmbTType.Name = "cmbTType";
            this.cmbTType.Size = new System.Drawing.Size(121, 21);
            this.cmbTType.TabIndex = 3;
            this.cmbTType.Text = " ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(21, 164);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(21, 13);
            this.label27.TabIndex = 4;
            this.label27.Text = "XT";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(21, 137);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 13);
            this.label28.TabIndex = 4;
            this.label28.Text = "FL";
            // 
            // cmbTBU
            // 
            this.cmbTBU.FormattingEnabled = true;
            this.cmbTBU.Location = new System.Drawing.Point(148, 107);
            this.cmbTBU.Name = "cmbTBU";
            this.cmbTBU.Size = new System.Drawing.Size(121, 21);
            this.cmbTBU.TabIndex = 3;
            this.cmbTBU.Text = " ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(21, 110);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Balanced / Unbalanced";
            // 
            // cmbTC
            // 
            this.cmbTC.FormattingEnabled = true;
            this.cmbTC.Location = new System.Drawing.Point(148, 80);
            this.cmbTC.Name = "cmbTC";
            this.cmbTC.Size = new System.Drawing.Size(121, 21);
            this.cmbTC.TabIndex = 3;
            this.cmbTC.Text = " ";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(21, 83);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(75, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Characteristic*";
            // 
            // cmbTSize
            // 
            this.cmbTSize.FormattingEnabled = true;
            this.cmbTSize.Location = new System.Drawing.Point(148, 53);
            this.cmbTSize.Name = "cmbTSize";
            this.cmbTSize.Size = new System.Drawing.Size(121, 21);
            this.cmbTSize.TabIndex = 3;
            this.cmbTSize.Text = "50";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(21, 56);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(31, 13);
            this.label31.TabIndex = 4;
            this.label31.Text = "Size*";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(21, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 13);
            this.label32.TabIndex = 4;
            this.label32.Text = "Type*";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cmbAAFV);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.cmbABR2);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Controls.Add(this.cmbABR1);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.cmbASize);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Location = new System.Drawing.Point(684, 294);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(247, 102);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "ACTUATOR";
            // 
            // cmbAAFV
            // 
            this.cmbAAFV.FormattingEnabled = true;
            this.cmbAAFV.Location = new System.Drawing.Point(107, 79);
            this.cmbAAFV.Name = "cmbAAFV";
            this.cmbAAFV.Size = new System.Drawing.Size(121, 21);
            this.cmbAAFV.TabIndex = 3;
            this.cmbAAFV.Text = "Close";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(21, 82);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(83, 13);
            this.label33.TabIndex = 4;
            this.label33.Text = "Air Failure Value";
            // 
            // cmbABR2
            // 
            this.cmbABR2.FormattingEnabled = true;
            this.cmbABR2.Location = new System.Drawing.Point(179, 48);
            this.cmbABR2.Name = "cmbABR2";
            this.cmbABR2.Size = new System.Drawing.Size(49, 21);
            this.cmbABR2.TabIndex = 3;
            this.cmbABR2.Text = " ";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(158, 52);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(12, 13);
            this.label34.TabIndex = 4;
            this.label34.Text = "/";
            // 
            // cmbABR1
            // 
            this.cmbABR1.FormattingEnabled = true;
            this.cmbABR1.Location = new System.Drawing.Point(107, 48);
            this.cmbABR1.Name = "cmbABR1";
            this.cmbABR1.Size = new System.Drawing.Size(46, 21);
            this.cmbABR1.TabIndex = 3;
            this.cmbABR1.Text = " ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(21, 52);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 13);
            this.label35.TabIndex = 4;
            this.label35.Text = "Bench Range*";
            // 
            // cmbASize
            // 
            this.cmbASize.FormattingEnabled = true;
            this.cmbASize.Location = new System.Drawing.Point(107, 22);
            this.cmbASize.Name = "cmbASize";
            this.cmbASize.Size = new System.Drawing.Size(121, 21);
            this.cmbASize.TabIndex = 3;
            this.cmbASize.Text = " ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(21, 25);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(31, 13);
            this.label36.TabIndex = 4;
            this.label36.Text = "Size*";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox4);
            this.groupBox9.Controls.Add(this.txtMAS);
            this.groupBox9.Controls.Add(this.groupBox1);
            this.groupBox9.Controls.Add(this.groupBox3);
            this.groupBox9.Controls.Add(this.groupBox2);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Controls.Add(this.cmbState);
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Controls.Add(this.cmbFluid);
            this.groupBox9.Location = new System.Drawing.Point(12, 12);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(1054, 184);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "SERVICE CONDITIONS";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.txtITSNF);
            this.groupBox12.Controls.Add(this.txtITSMaxF);
            this.groupBox12.Controls.Add(this.label38);
            this.groupBox12.Controls.Add(this.txtITSMinF);
            this.groupBox12.Controls.Add(this.label37);
            this.groupBox12.Controls.Add(this.label18);
            this.groupBox12.Controls.Add(this.cmbITSUnit);
            this.groupBox12.Controls.Add(this.label54);
            this.groupBox12.Location = new System.Drawing.Point(855, 29);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(180, 125);
            this.groupBox12.TabIndex = 13;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Inlet Temperature STEAM";
            // 
            // txtITSNF
            // 
            this.txtITSNF.Location = new System.Drawing.Point(75, 67);
            this.txtITSNF.Name = "txtITSNF";
            this.txtITSNF.Size = new System.Drawing.Size(100, 20);
            this.txtITSNF.TabIndex = 12;
            // 
            // txtITSMaxF
            // 
            this.txtITSMaxF.Location = new System.Drawing.Point(75, 41);
            this.txtITSMaxF.Name = "txtITSMaxF";
            this.txtITSMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtITSMaxF.TabIndex = 10;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(12, 44);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(52, 13);
            this.label38.TabIndex = 9;
            this.label38.Text = "Max Flow";
            // 
            // txtITSMinF
            // 
            this.txtITSMinF.Location = new System.Drawing.Point(75, 93);
            this.txtITSMinF.Name = "txtITSMinF";
            this.txtITSMinF.Size = new System.Drawing.Size(100, 20);
            this.txtITSMinF.TabIndex = 11;
            this.txtITSMinF.Text = " ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(12, 71);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(57, 13);
            this.label37.TabIndex = 8;
            this.label37.Text = "Norm Flow";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Min Flow";
            // 
            // cmbITSUnit
            // 
            this.cmbITSUnit.FormattingEnabled = true;
            this.cmbITSUnit.Location = new System.Drawing.Point(75, 16);
            this.cmbITSUnit.Name = "cmbITSUnit";
            this.cmbITSUnit.Size = new System.Drawing.Size(100, 21);
            this.cmbITSUnit.TabIndex = 3;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(16, 20);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(26, 13);
            this.label54.TabIndex = 4;
            this.label54.Text = "Unit";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.groupBox15);
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Controls.Add(this.txtCPress);
            this.groupBox10.Controls.Add(this.label50);
            this.groupBox10.Controls.Add(this.txtLPD);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Location = new System.Drawing.Point(12, 394);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(1054, 274);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Result";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.txtAMM);
            this.groupBox15.Controls.Add(this.label48);
            this.groupBox15.Controls.Add(this.txtAEA);
            this.groupBox15.Controls.Add(this.label49);
            this.groupBox15.Location = new System.Drawing.Point(636, 164);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(399, 100);
            this.groupBox15.TabIndex = 11;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "ACTUATOR";
            // 
            // txtAMM
            // 
            this.txtAMM.Location = new System.Drawing.Point(93, 21);
            this.txtAMM.Name = "txtAMM";
            this.txtAMM.Size = new System.Drawing.Size(286, 20);
            this.txtAMM.TabIndex = 10;
            this.txtAMM.Text = " ";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(11, 24);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(79, 13);
            this.label48.TabIndex = 9;
            this.label48.Text = "Mfr and Model*";
            // 
            // txtAEA
            // 
            this.txtAEA.Location = new System.Drawing.Point(93, 53);
            this.txtAEA.Name = "txtAEA";
            this.txtAEA.Size = new System.Drawing.Size(286, 20);
            this.txtAEA.TabIndex = 10;
            this.txtAEA.Text = " ";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(11, 53);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(45, 13);
            this.label49.TabIndex = 9;
            this.label49.Text = "Eff Area";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txtSWMWNF);
            this.groupBox11.Controls.Add(this.txtVSHRNF);
            this.groupBox11.Controls.Add(this.label39);
            this.groupBox11.Controls.Add(this.groupBox17);
            this.groupBox11.Controls.Add(this.groupBox14);
            this.groupBox11.Controls.Add(this.groupBox13);
            this.groupBox11.Controls.Add(this.groupBox16);
            this.groupBox11.Controls.Add(this.label40);
            this.groupBox11.Location = new System.Drawing.Point(18, 28);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(609, 240);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "SERVICE CONDITIONS";
            // 
            // txtSWMWNF
            // 
            this.txtSWMWNF.Location = new System.Drawing.Point(485, 51);
            this.txtSWMWNF.Name = "txtSWMWNF";
            this.txtSWMWNF.Size = new System.Drawing.Size(100, 20);
            this.txtSWMWNF.TabIndex = 12;
            this.txtSWMWNF.Text = " ";
            // 
            // txtVSHRNF
            // 
            this.txtVSHRNF.Location = new System.Drawing.Point(485, 99);
            this.txtVSHRNF.Name = "txtVSHRNF";
            this.txtVSHRNF.Size = new System.Drawing.Size(100, 20);
            this.txtVSHRNF.TabIndex = 10;
            this.txtVSHRNF.Text = " ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(313, 51);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(153, 13);
            this.label39.TabIndex = 8;
            this.label39.Text = "Spec Wt. / Mol Wt. Norm Flow";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.txtAPSNF);
            this.groupBox17.Controls.Add(this.txtAPSMaxF);
            this.groupBox17.Controls.Add(this.label59);
            this.groupBox17.Controls.Add(this.txtAPSMinF);
            this.groupBox17.Controls.Add(this.label60);
            this.groupBox17.Controls.Add(this.label61);
            this.groupBox17.Location = new System.Drawing.Point(201, 132);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(189, 100);
            this.groupBox17.TabIndex = 13;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Allowable / Predicted SPL*";
            // 
            // txtAPSNF
            // 
            this.txtAPSNF.Location = new System.Drawing.Point(75, 47);
            this.txtAPSNF.Name = "txtAPSNF";
            this.txtAPSNF.Size = new System.Drawing.Size(100, 20);
            this.txtAPSNF.TabIndex = 12;
            this.txtAPSNF.Text = " ";
            // 
            // txtAPSMaxF
            // 
            this.txtAPSMaxF.Location = new System.Drawing.Point(75, 21);
            this.txtAPSMaxF.Name = "txtAPSMaxF";
            this.txtAPSMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtAPSMaxF.TabIndex = 10;
            this.txtAPSMaxF.Text = " ";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(12, 24);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(52, 13);
            this.label59.TabIndex = 9;
            this.label59.Text = "Max Flow";
            // 
            // txtAPSMinF
            // 
            this.txtAPSMinF.Location = new System.Drawing.Point(75, 73);
            this.txtAPSMinF.Name = "txtAPSMinF";
            this.txtAPSMinF.Size = new System.Drawing.Size(100, 20);
            this.txtAPSMinF.TabIndex = 11;
            this.txtAPSMinF.Text = " ";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(12, 51);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(57, 13);
            this.label60.TabIndex = 8;
            this.label60.Text = "Norm Flow";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(12, 76);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(49, 13);
            this.label61.TabIndex = 7;
            this.label61.Text = "Min Flow";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.txtVVNF);
            this.groupBox14.Controls.Add(this.txtVVMaxF);
            this.groupBox14.Controls.Add(this.label44);
            this.groupBox14.Controls.Add(this.txtVVMinF);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Location = new System.Drawing.Point(403, 132);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(200, 100);
            this.groupBox14.TabIndex = 13;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Valve Velocity";
            // 
            // txtVVNF
            // 
            this.txtVVNF.Location = new System.Drawing.Point(82, 45);
            this.txtVVNF.Name = "txtVVNF";
            this.txtVVNF.Size = new System.Drawing.Size(100, 20);
            this.txtVVNF.TabIndex = 12;
            this.txtVVNF.Text = " ";
            // 
            // txtVVMaxF
            // 
            this.txtVVMaxF.Location = new System.Drawing.Point(82, 19);
            this.txtVVMaxF.Name = "txtVVMaxF";
            this.txtVVMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtVVMaxF.TabIndex = 10;
            this.txtVVMaxF.Text = " ";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(19, 22);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(52, 13);
            this.label44.TabIndex = 9;
            this.label44.Text = "Max Flow";
            // 
            // txtVVMinF
            // 
            this.txtVVMinF.Location = new System.Drawing.Point(82, 71);
            this.txtVVMinF.Name = "txtVVMinF";
            this.txtVVMinF.Size = new System.Drawing.Size(100, 20);
            this.txtVVMinF.TabIndex = 11;
            this.txtVVMinF.Text = " ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(19, 49);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 13);
            this.label45.TabIndex = 8;
            this.label45.Text = "Norm Flow";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(19, 74);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(49, 13);
            this.label46.TabIndex = 7;
            this.label46.Text = "Min Flow";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.txtRFCNF);
            this.groupBox13.Controls.Add(this.txtRFCMaxF);
            this.groupBox13.Controls.Add(this.label41);
            this.groupBox13.Controls.Add(this.txtRFCMinF);
            this.groupBox13.Controls.Add(this.label42);
            this.groupBox13.Controls.Add(this.label43);
            this.groupBox13.Location = new System.Drawing.Point(12, 132);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(182, 100);
            this.groupBox13.TabIndex = 13;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Required Flow Coefficient";
            // 
            // txtRFCNF
            // 
            this.txtRFCNF.Location = new System.Drawing.Point(76, 45);
            this.txtRFCNF.Name = "txtRFCNF";
            this.txtRFCNF.Size = new System.Drawing.Size(100, 20);
            this.txtRFCNF.TabIndex = 12;
            this.txtRFCNF.Text = " ";
            // 
            // txtRFCMaxF
            // 
            this.txtRFCMaxF.Location = new System.Drawing.Point(76, 19);
            this.txtRFCMaxF.Name = "txtRFCMaxF";
            this.txtRFCMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtRFCMaxF.TabIndex = 10;
            this.txtRFCMaxF.Text = " ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(13, 22);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 13);
            this.label41.TabIndex = 9;
            this.label41.Text = "Max Flow";
            // 
            // txtRFCMinF
            // 
            this.txtRFCMinF.Location = new System.Drawing.Point(76, 71);
            this.txtRFCMinF.Name = "txtRFCMinF";
            this.txtRFCMinF.Size = new System.Drawing.Size(100, 20);
            this.txtRFCMinF.TabIndex = 11;
            this.txtRFCMinF.Text = " ";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(13, 49);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(57, 13);
            this.label42.TabIndex = 8;
            this.label42.Text = "Norm Flow";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(13, 74);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(49, 13);
            this.label43.TabIndex = 7;
            this.label43.Text = "Min Flow";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.txtTravelNF);
            this.groupBox16.Controls.Add(this.txtTravelMaxF);
            this.groupBox16.Controls.Add(this.label55);
            this.groupBox16.Controls.Add(this.txtTravelMinF);
            this.groupBox16.Controls.Add(this.label56);
            this.groupBox16.Controls.Add(this.label57);
            this.groupBox16.Controls.Add(this.cmbTravelUnit);
            this.groupBox16.Controls.Add(this.label58);
            this.groupBox16.Location = new System.Drawing.Point(12, 13);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(189, 117);
            this.groupBox16.TabIndex = 13;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Travel";
            // 
            // txtTravelNF
            // 
            this.txtTravelNF.Location = new System.Drawing.Point(75, 65);
            this.txtTravelNF.Name = "txtTravelNF";
            this.txtTravelNF.Size = new System.Drawing.Size(100, 20);
            this.txtTravelNF.TabIndex = 12;
            // 
            // txtTravelMaxF
            // 
            this.txtTravelMaxF.Location = new System.Drawing.Point(75, 39);
            this.txtTravelMaxF.Name = "txtTravelMaxF";
            this.txtTravelMaxF.Size = new System.Drawing.Size(100, 20);
            this.txtTravelMaxF.TabIndex = 10;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(12, 44);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(52, 13);
            this.label55.TabIndex = 9;
            this.label55.Text = "Max Flow";
            // 
            // txtTravelMinF
            // 
            this.txtTravelMinF.Location = new System.Drawing.Point(75, 91);
            this.txtTravelMinF.Name = "txtTravelMinF";
            this.txtTravelMinF.Size = new System.Drawing.Size(100, 20);
            this.txtTravelMinF.TabIndex = 11;
            this.txtTravelMinF.Text = " ";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(12, 71);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(57, 13);
            this.label56.TabIndex = 8;
            this.label56.Text = "Norm Flow";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(12, 96);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(49, 13);
            this.label57.TabIndex = 7;
            this.label57.Text = "Min Flow";
            // 
            // cmbTravelUnit
            // 
            this.cmbTravelUnit.FormattingEnabled = true;
            this.cmbTravelUnit.Location = new System.Drawing.Point(75, 14);
            this.cmbTravelUnit.Name = "cmbTravelUnit";
            this.cmbTravelUnit.Size = new System.Drawing.Size(100, 21);
            this.cmbTravelUnit.TabIndex = 3;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(16, 20);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(26, 13);
            this.label58.TabIndex = 4;
            this.label58.Text = "Unit";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(270, 99);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(196, 13);
            this.label40.TabIndex = 9;
            this.label40.Text = "Viscosity / Spec Heats Ratio Norm Flow";
            // 
            // txtCPress
            // 
            this.txtCPress.Location = new System.Drawing.Point(915, 111);
            this.txtCPress.Name = "txtCPress";
            this.txtCPress.Size = new System.Drawing.Size(100, 20);
            this.txtCPress.TabIndex = 10;
            this.txtCPress.Text = " ";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(846, 111);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(51, 13);
            this.label50.TabIndex = 9;
            this.label50.Text = "Crit Press";
            // 
            // txtLPD
            // 
            this.txtLPD.Location = new System.Drawing.Point(915, 69);
            this.txtLPD.Name = "txtLPD";
            this.txtLPD.Size = new System.Drawing.Size(100, 20);
            this.txtLPD.TabIndex = 10;
            this.txtLPD.Text = " ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(741, 67);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(156, 13);
            this.label47.TabIndex = 9;
            this.label47.Text = "LINE Pipe velocity Downstream";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 651);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Armstrong delta 2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cmbFluid;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFRSO;
        private System.Windows.Forms.TextBox txtIPMaxF;
        private System.Windows.Forms.TextBox txtIPNF;
        private System.Windows.Forms.ComboBox cmbUnit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtIPMinF;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtOPMaxF;
        private System.Windows.Forms.TextBox txtOPMinF;
        private System.Windows.Forms.TextBox txtOPNF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtITMaxF;
        private System.Windows.Forms.TextBox txtITMinF;
        private System.Windows.Forms.TextBox txtITNF;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtFRMaxF;
        private System.Windows.Forms.TextBox txtFRMinF;
        private System.Windows.Forms.TextBox txtFRNF;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMAS;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbOut2;
        private System.Windows.Forms.ComboBox cmbOut1;
        private System.Windows.Forms.ComboBox cmbIn2;
        private System.Windows.Forms.ComboBox cmbIn1;
        private System.Windows.Forms.ComboBox cmbVBSize;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbVBSTD;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox cmbVBPT;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbVBPM;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbVBFD;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbVBRP;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtTrimXT;
        private System.Windows.Forms.TextBox txtTrimFL;
        private System.Windows.Forms.ComboBox cmbTType;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cmbTBU;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cmbTC;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cmbTSize;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox cmbAAFV;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox cmbABR2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cmbABR1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cmbASize;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txtSWMWNF;
        private System.Windows.Forms.TextBox txtVSHRNF;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox txtVVNF;
        private System.Windows.Forms.TextBox txtVVMaxF;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtVVMinF;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox txtRFCNF;
        private System.Windows.Forms.TextBox txtRFCMaxF;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtRFCMinF;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox txtITSNF;
        private System.Windows.Forms.TextBox txtITSMaxF;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtITSMinF;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox txtAMM;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtAEA;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtLPD;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtCPress;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox cmbIPUnit2;
        private System.Windows.Forms.ComboBox cmbIPUnit1;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox cmbITUnit;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox txtAPSNF;
        private System.Windows.Forms.TextBox txtAPSMaxF;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtAPSMinF;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox txtTravelNF;
        private System.Windows.Forms.TextBox txtTravelMaxF;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtTravelMinF;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmbTravelUnit;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox cmbITSUnit;
        private System.Windows.Forms.Label label54;
    }
}

