﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
namespace GetResultFormulas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            filename = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Demo.xlsx";
            cmbFluid.Items.Add("Acetylene");
            cmbFluid.Items.Add("AIR");
            cmbFluid.Items.Add("AMMONIA");
            cmbFluid.Items.Add("ARGON");
            cmbFluid.Items.Add("BENZENE");
            cmbFluid.Items.Add("BUTANE");
            cmbFluid.Items.Add("CARBON DIOXIDE");
            cmbFluid.Items.Add("CARBON MONOXIDE");
            cmbFluid.Items.Add("CHLORINE");
            cmbFluid.Items.Add("DOWTHERM-A");
            cmbFluid.Items.Add("ETHANE");
            cmbFluid.Items.Add("ETHYLENE");
            cmbFluid.Items.Add("FLUORINE");
            cmbFluid.Items.Add("GLYCOL");
            cmbFluid.Items.Add("HELIUM");
            cmbFluid.Items.Add("HYDROGEN CHLORIDE");
            cmbFluid.Items.Add("Hydrogen Sulphide");
            cmbFluid.Items.Add("ISOBUTANE");
            cmbFluid.Items.Add("ISOBUTYLENE");
            cmbFluid.Items.Add("METHANE");
            cmbFluid.Items.Add("METHANOL");
            cmbFluid.Items.Add("NATURAL GAS");
            cmbFluid.Items.Add("Neon , Krypton");
            cmbFluid.Items.Add("NITROGEN");
            cmbFluid.Items.Add("Nitrogen (Nitric) Oxide");
            cmbFluid.Items.Add("NITROUS OXIDE");
            cmbFluid.Items.Add("OXYGEN");
            cmbFluid.Items.Add("PHOSGENE");
            cmbFluid.Items.Add("PROPANE");
            cmbFluid.Items.Add("PROPYLENE");
            cmbFluid.Items.Add("STEAM Saturated");
            cmbFluid.Items.Add("STEAM Superheated");
            cmbFluid.Items.Add("Sulphur Dioxide");
            cmbFluid.Items.Add("WATER");
            cmbFluid.Items.Add("Other :");
            cmbFluid.Items.Add("2-Phased Flow :");

            cmbState.Items.Add("Liquid");
            cmbState.Items.Add("Steam Saturated");
            cmbState.Items.Add("Steam Superheated");
            cmbState.Items.Add("Gas");
            cmbState.Items.Add("Vapor");
            cmbState.Items.Add("2-Phased Liquid/Gas");
            cmbState.Items.Add("2-Phased Liquid/Vapor");
            cmbState.Items.Add("2-Phased Gas/Vapor");

            cmbUnit.Items.Add("Kg/h");
            cmbUnit.Items.Add("m3/h");
            cmbUnit.Items.Add("Nm3/h");
            cmbUnit.Items.Add("L/h");
            cmbUnit.Items.Add("Lb/h (Spec.)");
            cmbUnit.Items.Add("Sft3/h (Spec.)");
            cmbUnit.Items.Add("SCFH (Spec.)");
            cmbUnit.Items.Add("MMSCFD (Spec.)");

            cmbIn1.Items.Add("1/8\"");
            cmbIn1.Items.Add("1/4\"");
            cmbIn1.Items.Add("3/8\"");
            cmbIn1.Items.Add("1/4\"");
            cmbIn1.Items.Add("1\"");
            cmbIn1.Items.Add("1 1/4\"");
            cmbIn1.Items.Add("1 1/2\"");
            cmbIn1.Items.Add("2\"");
            cmbIn1.Items.Add("2 1/2\"");
            cmbIn1.Items.Add("3\"");
            cmbIn1.Items.Add("3 1/2\"");
            cmbIn1.Items.Add("4\"");
            cmbIn1.Items.Add("5\"");
            cmbIn1.Items.Add("6\"");
            cmbIn1.Items.Add("8\"");
            cmbIn1.Items.Add("10\"");
            cmbIn1.Items.Add("12\"");
            cmbIn1.Items.Add("14\"");
            cmbIn1.Items.Add("16\"");
            cmbIn1.Items.Add("18\"");
            cmbIn1.Items.Add("20\"");
            cmbIn1.Items.Add("24\"");

            cmbOut1.Items.Add("1/8\"");
            cmbOut1.Items.Add("1/4\"");
            cmbOut1.Items.Add("3/8\"");
            cmbOut1.Items.Add("1/4\"");
            cmbOut1.Items.Add("1\"");
            cmbOut1.Items.Add("1 1/4\"");
            cmbOut1.Items.Add("1 1/2\"");
            cmbOut1.Items.Add("2\"");
            cmbOut1.Items.Add("2 1/2\"");
            cmbOut1.Items.Add("3\"");
            cmbOut1.Items.Add("3 1/2\"");
            cmbOut1.Items.Add("4\"");
            cmbOut1.Items.Add("5\"");
            cmbOut1.Items.Add("6\"");
            cmbOut1.Items.Add("8\"");
            cmbOut1.Items.Add("10\"");
            cmbOut1.Items.Add("12\"");
            cmbOut1.Items.Add("14\"");
            cmbOut1.Items.Add("16\"");
            cmbOut1.Items.Add("18\"");
            cmbOut1.Items.Add("20\"");
            cmbOut1.Items.Add("24\"");

            cmbIn2.Items.Add("STD");
            cmbIn2.Items.Add("XS");
            cmbIn2.Items.Add("XXS");
            cmbIn2.Items.Add("10");
            cmbIn2.Items.Add("20");
            cmbIn2.Items.Add("30");
            cmbIn2.Items.Add("40");
            cmbIn2.Items.Add("60");
            cmbIn2.Items.Add("80");
            cmbIn2.Items.Add("100");
            cmbIn2.Items.Add("120");
            cmbIn2.Items.Add("140");
            cmbIn2.Items.Add("160");

            cmbOut2.Items.Add("STD");
            cmbOut2.Items.Add("XS");
            cmbOut2.Items.Add("XXS");
            cmbOut2.Items.Add("10");
            cmbOut2.Items.Add("20");
            cmbOut2.Items.Add("30");
            cmbOut2.Items.Add("40");
            cmbOut2.Items.Add("60");
            cmbOut2.Items.Add("80");
            cmbOut2.Items.Add("100");
            cmbOut2.Items.Add("120");
            cmbOut2.Items.Add("140");
            cmbOut2.Items.Add("160");

            cmbVBSTD.Items.Add("DIN");
            cmbVBSTD.Items.Add("ANSI");

            cmbVBSize.Items.Add("15");
            cmbVBSize.Items.Add("20");
            cmbVBSize.Items.Add("25");
            cmbVBSize.Items.Add("32");
            cmbVBSize.Items.Add("40");
            cmbVBSize.Items.Add("50");
            cmbVBSize.Items.Add("65");
            cmbVBSize.Items.Add("80");
            cmbVBSize.Items.Add("100");
            cmbVBSize.Items.Add("125");
            cmbVBSize.Items.Add("150");
            cmbVBSize.Items.Add("200");
            cmbVBSize.Items.Add("250");
            cmbVBSize.Items.Add("300");
            cmbVBSize.Items.Add("1/2\"");
            cmbVBSize.Items.Add("3/4\"");
            cmbVBSize.Items.Add("1\"");
            cmbVBSize.Items.Add("1.1/2\"");
            cmbVBSize.Items.Add("2\"");
            cmbVBSize.Items.Add("3\"");
            cmbVBSize.Items.Add("4\"");
            cmbVBSize.Items.Add("6\"");
            cmbVBSize.Items.Add("8\"");
            cmbVBSize.Items.Add("10\"");
            cmbVBSize.Items.Add("12\"");
            cmbVBSize.Items.Add("Other");

            cmbVBRP.Items.Add("16");
            cmbVBRP.Items.Add("40");
            cmbVBRP.Items.Add("100");
            cmbVBRP.Items.Add("150");
            cmbVBRP.Items.Add("300");
            cmbVBRP.Items.Add("600");
            cmbVBRP.Items.Add("900");
            cmbVBRP.Items.Add("1500");

            cmbVBFD.Items.Add("Open");
            cmbVBFD.Items.Add("Close");

            cmbVBPM.Items.Add("PTFE");
            cmbVBPM.Items.Add("Graphite");

            cmbVBPT.Items.Add("PTFE V-ring");
            cmbVBPT.Items.Add("PTFE TA-Luft");
            cmbVBPT.Items.Add("Graphite");
            cmbVBPT.Items.Add("Graphite TA-Luft");

            cmbTType.Items.Add("Parabolic");
            cmbTType.Items.Add("Perforated Plug");
            cmbTType.Items.Add("Multi-Cage");
            cmbTType.Items.Add("Multi-Cage");

            cmbTSize.Items.Add("300");
            cmbTSize.Items.Add("250");
            cmbTSize.Items.Add("200");
            cmbTSize.Items.Add("150");
            cmbTSize.Items.Add("125");
            cmbTSize.Items.Add("100");
            cmbTSize.Items.Add("80");
            cmbTSize.Items.Add("65");
            cmbTSize.Items.Add("50");
            cmbTSize.Items.Add("40");
            cmbTSize.Items.Add("32");
            cmbTSize.Items.Add("25");
            cmbTSize.Items.Add("20");
            cmbTSize.Items.Add("15");
            cmbTSize.Items.Add("10");
            cmbTSize.Items.Add("5");
            cmbTSize.Items.Add("3");

            cmbTC.Items.Add("Equalpercent");
            cmbTC.Items.Add("Linear");
            cmbTC.Items.Add("On-Off");
            cmbTC.Items.Add("Bi-Linear");
            cmbTC.Items.Add("Tri-Linear");
            cmbTC.Items.Add("Soecial");

            cmbTBU.Items.Add("Unbalanced");
            cmbTBU.Items.Add("PTFE Rings [L]");
            cmbTBU.Items.Add("PTFE Rings [G]");
            cmbTBU.Items.Add("Graphite rings [L+Sat.Steam]");
            cmbTBU.Items.Add("Graphite rings [G]");
            cmbTBU.Items.Add("Steel Rings [L+Sat.Steam]");
            cmbTBU.Items.Add("Steel Rings [G]");

            cmbASize.Items.Add("127");
            cmbASize.Items.Add("252");
            cmbASize.Items.Add("502");
            cmbASize.Items.Add("700");
            cmbASize.Items.Add("1502");
            cmbASize.Items.Add("3002");

            cmbABR1.Items.Add("0.2");
            cmbABR1.Items.Add("0.4");
            cmbABR1.Items.Add("0.5");
            cmbABR1.Items.Add("0.75");
            cmbABR1.Items.Add("0.8");
            cmbABR1.Items.Add("0.9");
            cmbABR1.Items.Add("1.0");
            cmbABR1.Items.Add("1.2");
            cmbABR1.Items.Add("1.2");
            cmbABR1.Items.Add("1.3");
            cmbABR1.Items.Add("1.4");
            cmbABR1.Items.Add("1.5");
            cmbABR1.Items.Add("1.8");
            cmbABR1.Items.Add("2.0");
            cmbABR1.Items.Add("2.3");
            cmbABR1.Items.Add("2.6");
            cmbABR1.Items.Add("2.6");
            cmbABR1.Items.Add("2.7");
            cmbABR1.Items.Add("3.0");

            cmbABR2.Items.Add("1.0");
            cmbABR2.Items.Add("1.4");
            cmbABR2.Items.Add("1.6");
            cmbABR2.Items.Add("1.9");
            cmbABR2.Items.Add("2.0");
            cmbABR2.Items.Add("2.1");
            cmbABR2.Items.Add("2.4");
            cmbABR2.Items.Add("2.6");
            cmbABR2.Items.Add("2.7");
            cmbABR2.Items.Add("3.4");
            cmbABR2.Items.Add("3.5");
            cmbABR2.Items.Add("3.8");
            cmbABR2.Items.Add("4.1");
            cmbABR2.Items.Add("4.2");
            cmbABR2.Items.Add("4.3");
            cmbABR2.Items.Add("4.8");

            cmbAAFV.Items.Add("Open");
            cmbAAFV.Items.Add("Close");
            cmbAAFV.Items.Add("Lock (Open)");
            cmbAAFV.Items.Add("Lock (Close)");

            cmbIPUnit1.Items.Add("kPa");
            cmbIPUnit1.Items.Add("Bar");
            cmbIPUnit1.Items.Add("psi");
            cmbIPUnit1.Items.Add("kg/cm2");
            cmbIPUnit1.Items.Add("mmH2O (Spec.)");
            cmbIPUnit1.Items.Add("mmHg (Spec.)");
            
            cmbIPUnit2.Items.Add("(g)");
            cmbIPUnit2.Items.Add("(a)");

            cmbITUnit.Items.Add("°F");
            cmbITUnit.Items.Add("°C");
            cmbITUnit.Items.Add("°K (Spec.)");

            cmbITSUnit.Items.Add("°F");
            cmbITSUnit.Items.Add("°C");
            cmbITSUnit.Items.Add("°K (Spec.)");

            cmbTravelUnit.Items.Add("%");
            cmbTravelUnit.Items.Add("Degrees");


            cmbTravelUnit.SelectedIndex = 1;
            cmbITSUnit.SelectedIndex = 1;
            cmbITUnit.SelectedIndex = 1;
            cmbIPUnit2.SelectedIndex = 1;
            cmbIPUnit1.SelectedIndex = 1;

            cmbAAFV.SelectedIndex = 1;
            cmbABR1.SelectedIndex = 1;
            cmbABR2.SelectedIndex = 1;
            cmbASize.SelectedIndex = 1;
            cmbFluid.SelectedIndex = 1;
            cmbIn1.SelectedIndex = 1;
            cmbIn2.SelectedIndex = 1;
            cmbOut1.SelectedIndex = 1;
            cmbOut2.SelectedIndex = 1;
            cmbState.SelectedIndex = 1;
            cmbTBU.SelectedIndex = 1;
            cmbTC.SelectedIndex = 1;
            cmbTSize.SelectedIndex = 1;
            cmbTType.SelectedIndex = 1;
            cmbUnit.SelectedIndex = 1;
            cmbVBFD.SelectedIndex = 1;
            cmbVBPM.SelectedIndex = 1;
            cmbVBPT.SelectedIndex = 1;
            cmbVBRP.SelectedIndex = 1;
            cmbVBSize.SelectedIndex = 1;
            cmbVBSTD.SelectedIndex = 1;

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txtCPress.Text = "";

            txtTravelMaxF.Text = "";
            txtTravelNF.Text = "";
            txtTravelMinF.Text = "";

            txtAPSMaxF.Text = "";
            txtAPSNF.Text = "";
            txtAPSMinF.Text = "";

            txtSWMWNF.Text = "";
            txtVSHRNF.Text = "";

            txtRFCMaxF.Text = "";
            txtRFCNF.Text = "";
            txtRFCMinF.Text = "";

            txtVVMaxF.Text = "";
            txtVVNF.Text = "";
            txtVVMinF.Text = "";

            txtLPD.Text = "";
            txtAMM.Text = "";
            txtAEA.Text = "";

            Application excel = new Application();

            Workbook workbook = excel.Workbooks.Open(filename, ReadOnly: false, Editable: true);
            Worksheet worksheet = workbook.Worksheets["SELECTION"] as Worksheet;
            if (worksheet == null)
                return;
            try
            {

                Range row1 = worksheet.Rows.Cells[10, 5];
                row1.Value = cmbFluid.SelectedItem.ToString();

                Range row2 = worksheet.Rows.Cells[10, 20];
                row2.Value = cmbState.SelectedItem.ToString();

                Range row3 = worksheet.Rows.Cells[12, 12];
                row3.Value = cmbUnit.SelectedItem.ToString();

                Range row4 = worksheet.Rows.Cells[12, 18];
                row4.Value = txtFRMaxF.Text;

                Range row5 = worksheet.Rows.Cells[12, 24];
                row5.Value = txtFRNF.Text;

                Range row6 = worksheet.Rows.Cells[12, 30];
                row6.Value = txtFRMinF.Text;

                Range row7 = worksheet.Rows.Cells[12, 36];
                row7.Value = txtFRSO.Text;

                Range row8 = worksheet.Rows.Cells[14, 18];
                row8.Value = txtIPMaxF.Text;

                Range row9 = worksheet.Rows.Cells[14, 24];
                row9.Value = txtIPNF.Text;

                Range row10 = worksheet.Rows.Cells[14, 30];
                row10.Value = txtIPMinF.Text;

                Range row11 = worksheet.Rows.Cells[15, 18];
                row11.Value = txtOPMaxF.Text;

                Range row12 = worksheet.Rows.Cells[15, 24];
                row12.Value = txtOPNF.Text;

                Range row13 = worksheet.Rows.Cells[15, 30];
                row13.Value = txtOPMinF.Text;

                Range row14 = worksheet.Rows.Cells[16, 18];
                row14.Value = txtITMaxF.Text;

                Range row15 = worksheet.Rows.Cells[16, 24];
                row15.Value = txtITNF.Text;

                Range row16 = worksheet.Rows.Cells[16, 30];
                row16.Value = txtITMinF.Text;

                Range row17 = worksheet.Rows.Cells[24, 36];
                row17.Value = txtMAS.Text;

                Range row18 = worksheet.Rows.Cells[25, 9];
                row18.Value = cmbIn1.SelectedItem.ToString();

                Range row19 = worksheet.Rows.Cells[25, 11];
                row19.Value = cmbIn2.SelectedItem.ToString();

                Range row20 = worksheet.Rows.Cells[26, 9];
                row20.Value = cmbOut1.SelectedItem.ToString();

                Range row21 = worksheet.Rows.Cells[26, 11];
                row21.Value = cmbOut2.SelectedItem.ToString();

                Range row22 = worksheet.Rows.Cells[29, 6];
                row22.Value = cmbVBSTD.SelectedItem.ToString();

                Range row23 = worksheet.Rows.Cells[29, 10];
                row23.Value = cmbVBSize.SelectedItem.ToString();

                Range row24 = worksheet.Rows.Cells[29, 16];
                row24.Value = cmbVBRP.SelectedItem.ToString();

                Range row25 = worksheet.Rows.Cells[38, 8];
                row25.Value = cmbVBFD.SelectedItem.ToString();

                Range row26 = worksheet.Rows.Cells[42, 9];
                row26.Value = cmbVBPM.SelectedItem.ToString();

                Range row27 = worksheet.Rows.Cells[43, 8];
                row27.Value = cmbVBPT.SelectedItem.ToString();

                Range row28 = worksheet.Rows.Cells[45, 6];
                row28.Value = cmbTType.SelectedItem.ToString();

                Range row29 = worksheet.Rows.Cells[46, 6];
                row29.Value = cmbTSize.SelectedItem.ToString();

                Range row30 = worksheet.Rows.Cells[47, 8];
                row30.Value = cmbTC.SelectedItem.ToString();

                Range row31 = worksheet.Rows.Cells[48, 10];
                row31.Value = cmbTBU.SelectedItem.ToString();

                Range row32 = worksheet.Rows.Cells[49, 13];
                row31.Value = txtTrimFL.Text;

                Range row33 = worksheet.Rows.Cells[49, 18];
                row33.Value = txtTrimXT.Text;

                Range row34 = worksheet.Rows.Cells[27, 26];
                row34.Value = cmbASize.SelectedItem.ToString();

                Range row35 = worksheet.Rows.Cells[34, 28];
                row35.Value = cmbABR1.SelectedItem.ToString();

                Range row36 = worksheet.Rows.Cells[34, 36];
                row36.Value = cmbABR2.SelectedItem.ToString();

                Range row37 = worksheet.Rows.Cells[37, 29];
                row37.Value = cmbAAFV.SelectedItem.ToString();

                Range row38 = worksheet.Rows.Cells[14, 12];
                row38.Value = cmbIPUnit1.SelectedItem.ToString();

                Range row39 = worksheet.Rows.Cells[14, 16];
                row39.Value = cmbIPUnit2.SelectedItem.ToString();

                Range row40 = worksheet.Rows.Cells[16, 12];
                row40.Value = cmbITUnit.SelectedItem.ToString();

                Range row41 = worksheet.Rows.Cells[17, 12];
                row41.Value = cmbITSUnit.SelectedItem.ToString();

                Range row42 = worksheet.Rows.Cells[22, 12];
                row42.Value = cmbTravelUnit.SelectedItem.ToString();

                Range row43 = worksheet.Rows.Cells[17, 18];
                row43.Value = txtITSMaxF.Text;

                Range row44 = worksheet.Rows.Cells[17, 24];
                row44.Value = txtITSNF.Text;

                Range row45 = worksheet.Rows.Cells[17, 30];
                row45.Value = txtITSMinF.Text;




                txtCPress.Text = isValidS(worksheet.Rows.Cells[10, 30]);

                txtSWMWNF.Text = isValidS(worksheet.Rows.Cells[18, 24]);
                txtVSHRNF.Text = isValidS(worksheet.Rows.Cells[19, 24]);

                txtRFCMaxF.Text = isValidS(worksheet.Rows.Cells[21, 18]);
                txtRFCNF.Text = isValidS(worksheet.Rows.Cells[21, 24]);
                txtRFCMinF.Text = isValidS(worksheet.Rows.Cells[21, 30]);

                txtVVMaxF.Text = isValidS(worksheet.Rows.Cells[24, 18]);
                txtVVNF.Text = isValidS(worksheet.Rows.Cells[24, 24]);
                txtVVMinF.Text = isValidS(worksheet.Rows.Cells[24, 30]);

                txtTravelMaxF.Text = isValidS(worksheet.Rows.Cells[22, 18]);
                txtTravelNF.Text = isValidS(worksheet.Rows.Cells[22, 24]);
                txtTravelMinF.Text = isValidS(worksheet.Rows.Cells[22, 30]);

                txtAPSMaxF.Text = isValidS(worksheet.Rows.Cells[23, 18]);
                txtAPSNF.Text = isValidS(worksheet.Rows.Cells[23, 24]);
                txtAPSMinF.Text = isValidS(worksheet.Rows.Cells[23, 30]);
                txtAEA.Text = isValidS(worksheet.Rows.Cells[27, 36]);
                txtLPD.Text = isValidS(worksheet.Rows.Cells[26, 13]);

                txtAMM.Text = worksheet.Rows.Cells[26, 28].Value.ToString();
                

            }
            catch (Exception ee)
            {

                _ = MessageBox.Show(ee.ToString());
            }
            finally
            {
                excel.ActiveWorkbook.Save();
                excel.Application.Quit();
                excel.Quit();
                _ = MessageBox.Show("You are done");
            }



            
        }
        string filename = "";
        public string isValidS(Range rng)
        {
            if (rng.Value == null)
            {
                return "";
            }
            string str = rng.Value.ToString();
            try
            {
                double d = 0;
                Double.TryParse(str, out d);
                if (d > 0)
                {
                    return str;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            return "#";
        }

    }
}
